# Codename: ClearMyBeach

This is an attempt to gather some people and clean up trash in as a group activity

## Prerequsistes

The project currently depends on Python3.6+ (tested with Python3.8).
Third party libraries used so far can be install by typing:

    pip3 install folium flask

Folium is a geografic map display plugin. Comes with cards out of the box,
marker insertion and display features.
Flask is, well... Flask.

## Demo

To see something, execute below command and afterwards inspect *index.html*.

    python3 interactive_map.py
